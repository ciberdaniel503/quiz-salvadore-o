// ==========================================
// EL RETO SALVADOREÑO 🇸🇻
// ==========================================


// ==========================================
// MÚSICA
// ==========================================

const musicaFondo = document.getElementById("musicaFondo");
const fuenteMusica = document.getElementById("fuenteMusica");
const seleccionMusica = document.getElementById("seleccionMusica");
const btnMusica = document.getElementById("btnMusica");

let musicaActiva = true;


// Volumen
if (musicaFondo) {
    musicaFondo.volume = 0.25;
}


// ==========================================
// CAMBIAR MÚSICA
// ==========================================

seleccionMusica.addEventListener("change", function () {

    const nuevaMusica = seleccionMusica.value;

    musicaFondo.pause();

    fuenteMusica.src = "audio/" + nuevaMusica;

    musicaFondo.load();

    musicaActiva = true;

    btnMusica.textContent = "🔊";
});


// ==========================================
// BOTÓN MÚSICA
// ==========================================

btnMusica.addEventListener("click", function () {

    if (musicaActiva) {

        musicaFondo.pause();

        musicaActiva = false;

        btnMusica.textContent = "🔇";

    } else {

        musicaFondo.play().catch(function (error) {

            console.log(
                "No se pudo reproducir la música:",
                error
            );

        });

        musicaActiva = true;

        btnMusica.textContent = "🔊";
    }
});


// ==========================================
// PREGUNTAS
// ==========================================

const preguntas = [

    {
        categoria: "Historia",
        pregunta: "¿En qué año se proclamó la independencia de Centroamérica?",
        imagen: "📜",
        respuestas: [
            "1810",
            "1815",
            "1821",
            "1830"
        ],
        correcta: 2
    },

    {
        categoria: "Historia",
        pregunta: "¿Qué fecha se conmemora como la Independencia de Centroamérica?",
        imagen: "🇸🇻",
        respuestas: [
            "5 de noviembre",
            "15 de septiembre",
            "24 de diciembre",
            "1 de enero"
        ],
        correcta: 1
    },

    {
        categoria: "Historia",
        pregunta: "¿Quién fue uno de los principales próceres de la independencia centroamericana?",
        imagen: "📖",
        respuestas: [
            "Gerardo Barrios",
            "Francisco Morazán",
            "José Matías Delgado",
            "Manuel José Arce"
        ],
        correcta: 2
    },

    {
        categoria: "Geografía",
        pregunta: "¿ Cual es el nombre del volcan de San Miguel?",
        imagen: "🌋",
        respuestas: [
            "La perla de oriente",
            " Volcan Chaparrastique",
            "La curruncha",
            "El garrobero"
            

        ],
        correcta: 1
    },

    {
        categoria: "Geografía",
        pregunta: "¿Cuál es el lago más grande de El Salvador?",
        imagen: "🏞️",
        respuestas: [
            "Lago de Güija",
            "Lago de Coatepeque",
            "Lago de Ilopango",
            "Lago Suchitlán"
        ],
        correcta: 2
    },

    {
        categoria: "Geografía",
        pregunta: "¿Cuál es el departamento ubicado más al oriente de El Salvador?",
        imagen: "🗺️",
        respuestas: [
            "San Miguel",
            "Usulután",
            "La Unión",
            "Morazán"
        ],
        correcta: 2
    },

    {
        categoria: "Gastronomía",
        pregunta: "¿Cuál de estos tipos de pupusa es uno de los más tradicionales?",
        imagen: "🫓",
        respuestas: [
            "Revueltas",
            "Pizza",
            "Hamburguesa",
            "Taco"
        ],
        correcta: 0
    },

    {
        categoria: "Gastronomía",
        pregunta: "¿Con qué se acompaña tradicionalmente una pupusa?",
        imagen: "🥬",
        respuestas: [
            "Curtido",
            "Guacamole",
            "Ensalada rusa",
            "Papas fritas"
        ],
        correcta: 0
    },

    {
        categoria: "Gastronomía",
        pregunta: "¿Cuál de estos es un platillo tradicional salvadoreño?",
        imagen: "🍽️",
        respuestas: [
            "Yuca con chicharrón",
            "Sushi",
            "Paella",
            "Ramen"
        ],
        correcta: 0
    },

    {
        categoria: "Símbolos patrios",
        pregunta: "¿Cuál es el ave nacional de El Salvador?",
        imagen: "🐦",
        respuestas: [
            "Águila",
            "Torogoz",
            "Colibrí",
            "Loro"
        ],
        correcta: 1
    },

    {
        categoria: "Símbolos patrios",
        pregunta: "¿Cuál es la flor nacional de El Salvador?",
        imagen: "🌼",
        respuestas: [
            "Rosa",
            "Orquídea",
            "Flor de izote",
            "Girasol"
        ],
        correcta: 2
    },

    {
        categoria: "Símbolos patrios",
        pregunta: "¿Cuál es uno de los árboles nacionales de El Salvador?",
        imagen: "🌳",
        respuestas: [
            "Maquilishuat",
            "Pino",
            "Roble",
            "Ciprés"
        ],
        correcta: 0
    },

    {
        categoria: "Cultura",
        pregunta: "¿En qué ciudad se celebran las fiestas patronales en honor a la Virgen de la Paz?",
        imagen: "🎉",
        respuestas: [
            "Santa Ana",
            "San Salvador",
            "San Miguel",
            "La Unión"
        ],
        correcta: 2
    },

    {
        categoria: "Cultura y lugares",
        pregunta: "¿Cuál de estos lugares turísticos se encuentra en El Salvador?",
        imagen: "🏔️",
        respuestas: [
            "El Boquerón",
            "Machu Picchu",
            "Chichén Itzá",
            "Canal de Panamá"
        ],
        correcta: 0
    },

    {
        categoria: "Símbolos patrios",
        pregunta: "¿Cuál es el otro árbol nacional de El Salvador además del maquilishuat?",
        imagen: "🌲",
        respuestas: [
            "Bálsamo",
            "Cedro",
            "Pino",
            "Eucalipto"
        ],
        correcta: 0
    }

];


// ==========================================
// VARIABLES DEL JUEGO
// ==========================================

let nombreJugador = "";

let preguntaActual = 0;

let puntos = 0;

let aciertos = 0;

let respondida = false;


// ==========================================
// ELEMENTOS HTML
// ==========================================

const pantallaInicio =
    document.getElementById("inicio");

const pantallaJuego =
    document.getElementById("juego");

const pantallaResultado =
    document.getElementById("resultado");


const inputNombre =
    document.getElementById("nombre");


const txtJugador =
    document.getElementById("txtJugador");

const txtPuntos =
    document.getElementById("txtPuntos");

const txtCategoria =
    document.getElementById("txtCategoria");

const txtNumeroPregunta =
    document.getElementById("txtNumeroPregunta");


const barraProgreso =
    document.getElementById("barraProgreso");


const imagenPregunta =
    document.getElementById("imagenPregunta");

const txtPregunta =
    document.getElementById("txtPregunta");


const respuestasContainer =
    document.getElementById("respuestas");


const mensajeRespuesta =
    document.getElementById("mensajeRespuesta");


const btnComenzar =
    document.getElementById("btnComenzar");


const btnSiguiente =
    document.getElementById("btnSiguiente");


const btnJugarNuevamente =
    document.getElementById("btnJugarNuevamente");


// ==========================================
// CAMBIAR PANTALLA
// ==========================================

function mostrarPantalla(pantalla) {

    pantallaInicio.classList.remove("activa");

    pantallaJuego.classList.remove("activa");

    pantallaResultado.classList.remove("activa");

    pantalla.classList.add("activa");
}


// ==========================================
// COMENZAR JUEGO
// ==========================================

btnComenzar.addEventListener("click", function () {

    nombreJugador =
        inputNombre.value.trim();


    if (nombreJugador === "") {

        nombreJugador = "Jugador";

    }


    preguntaActual = 0;

    puntos = 0;

    aciertos = 0;

    respondida = false;


    txtJugador.textContent =
        nombreJugador;


    // Comenzar música
    musicaFondo.currentTime = 0;


    musicaFondo.play().catch(function (error) {

        console.log(
            "El navegador bloqueó la reproducción:",
            error
        );

    });


    musicaActiva = true;

    btnMusica.textContent = "🔊";


    mostrarPantalla(pantallaJuego);

    mostrarPregunta();

});


// ==========================================
// MOSTRAR PREGUNTA
// ==========================================

function mostrarPregunta() {

    const pregunta =
        preguntas[preguntaActual];


    respondida = false;


    txtNumeroPregunta.textContent =
        `Pregunta ${preguntaActual + 1} de ${preguntas.length}`;


    txtCategoria.textContent =
        pregunta.categoria;


    imagenPregunta.textContent =
        pregunta.imagen;


    txtPregunta.textContent =
        pregunta.pregunta;


    txtPuntos.textContent =
        puntos;


    const progreso =
        ((preguntaActual) / preguntas.length) * 100;


    barraProgreso.style.width =
        `${progreso}%`;


    respuestasContainer.innerHTML = "";


    mensajeRespuesta.textContent = "";

    mensajeRespuesta.className = "";


    btnSiguiente.style.display =
        "none";


    pregunta.respuestas.forEach(
        function (respuesta, indice) {

            const boton =
                document.createElement("button");


            boton.classList.add("respuesta");


            boton.textContent =
                respuesta;


            boton.addEventListener(
                "click",
                function () {

                    comprobarRespuesta(
                        indice,
                        boton
                    );

                }
            );


            respuestasContainer.appendChild(
                boton
            );

        }
    );
}


// ==========================================
// COMPROBAR RESPUESTA
// ==========================================

function comprobarRespuesta(
    indiceSeleccionado,
    botonSeleccionado
) {

    if (respondida) {

        return;

    }


    respondida = true;


    const pregunta =
        preguntas[preguntaActual];


    const botones =
        document.querySelectorAll(
            ".respuesta"
        );


    botones.forEach(function (boton) {

        boton.disabled = true;

    });


    if (
        indiceSeleccionado ===
        pregunta.correcta
    ) {

        puntos += 100;

        aciertos++;


        botonSeleccionado.classList.add(
            "correcta"
        );


        mensajeRespuesta.textContent =
            "✅ ¡Correcto! +100 puntos";


        mensajeRespuesta.classList.add(
            "correcto"
        );

    } else {

        botonSeleccionado.classList.add(
            "incorrecta"
        );


        botones[
            pregunta.correcta
        ].classList.add(
            "correcta"
        );


        mensajeRespuesta.textContent =
            "❌ Incorrecto. La respuesta correcta era: " +
            pregunta.respuestas[
                pregunta.correcta
            ];


        mensajeRespuesta.classList.add(
            "incorrecto"
        );

    }


    txtPuntos.textContent =
        puntos;


    btnSiguiente.style.display =
        "block";
}


// ==========================================
// SIGUIENTE
// ==========================================

btnSiguiente.addEventListener(
    "click",
    function () {

        preguntaActual++;


        if (
            preguntaActual <
            preguntas.length
        ) {

            mostrarPregunta();

        } else {

            mostrarResultado();

        }

    }
);


// ==========================================
// RESULTADO
// ==========================================

function mostrarResultado() {

    mostrarPantalla(
        pantallaResultado
    );


    barraProgreso.style.width =
        "100%";


    const tituloResultado =
        document.getElementById(
            "tituloResultado"
        );


    const textoResultado =
        document.getElementById(
            "textoResultado"
        );


    const puntosFinales =
        document.getElementById(
            "puntosFinales"
        );


    const detalleResultado =
        document.getElementById(
            "detalleResultado"
        );


    puntosFinales.textContent =
        `${puntos} puntos`;


    detalleResultado.textContent =
        `${aciertos} de ${preguntas.length} respuestas correctas`;


    if (puntos === 1500) {

        tituloResultado.textContent =
            "🇸🇻 ¡PERFECTO!";


        textoResultado.textContent =
            `¡Excelente trabajo, ${nombreJugador}!`;

    }

    else if (puntos >= 1200) {

        tituloResultado.textContent =
            "🔥 ¡Excelente!";


        textoResultado.textContent =
            `¡Sabes mucho sobre El Salvador, ${nombreJugador}!`;

    }

    else if (puntos >= 900) {

        tituloResultado.textContent =
            "👏 ¡Muy bien!";


        textoResultado.textContent =
            `¡Buen trabajo, ${nombreJugador}!`;

    }

    else if (puntos >= 600) {

        tituloResultado.textContent =
            "👍 ¡Buen trabajo!";


        textoResultado.textContent =
            `¡Vas por buen camino, ${nombreJugador}!`;

    }

    else {

        tituloResultado.textContent =
            "💪 ¡Buen intento!";


        textoResultado.textContent =
            `Puedes intentarlo nuevamente, ${nombreJugador}.`;

    }

}


// ==========================================
// JUGAR NUEVAMENTE
// ==========================================

btnJugarNuevamente.addEventListener(
    "click",
    function () {

        preguntaActual = 0;

        puntos = 0;

        aciertos = 0;

        respondida = false;


        txtJugador.textContent =
            nombreJugador;


        musicaFondo.currentTime = 0;


        musicaFondo.play().catch(
            function (error) {

                console.log(
                    "No se pudo reproducir la música:",
                    error
                );

            }
        );


        musicaActiva = true;

        btnMusica.textContent = "🔊";


        mostrarPantalla(
            pantallaJuego
        );


        mostrarPregunta();

    }
);